﻿namespace GestionSerre
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.CloseSerialPort = new System.Windows.Forms.Button();
            this.OpenSerialPort = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.BChauffage = new System.Windows.Forms.Button();
            this.BVanne = new System.Windows.Forms.Button();
            this.BVolet = new System.Windows.Forms.Button();
            this.BLumiere = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BMaJ = new System.Windows.Forms.Button();
            this.TBLumiere = new System.Windows.Forms.TextBox();
            this.TBHygro = new System.Windows.Forms.TextBox();
            this.TBTempExt = new System.Windows.Forms.TextBox();
            this.TBTempInt = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.CBStop = new System.Windows.Forms.ComboBox();
            this.CBParity = new System.Windows.Forms.ComboBox();
            this.BSaveConfigPort = new System.Windows.Forms.Button();
            this.TBBit = new System.Windows.Forms.TextBox();
            this.TBBaudRate = new System.Windows.Forms.TextBox();
            this.TBSerialPort = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.BEraseMemory = new System.Windows.Forms.Button();
            this.LNbreRec = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.BRecupData = new System.Windows.Forms.Button();
            this.PGBDownload = new System.Windows.Forms.ProgressBar();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.PBLedConnexion = new System.Windows.Forms.PictureBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label11 = new System.Windows.Forms.Label();
            this.LVersion = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aProposToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBLedConnexion)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CloseSerialPort
            // 
            this.CloseSerialPort.Location = new System.Drawing.Point(320, 171);
            this.CloseSerialPort.Name = "CloseSerialPort";
            this.CloseSerialPort.Size = new System.Drawing.Size(84, 23);
            this.CloseSerialPort.TabIndex = 0;
            this.CloseSerialPort.Text = "Fermer le port";
            this.CloseSerialPort.UseVisualStyleBackColor = true;
            this.CloseSerialPort.Click += new System.EventHandler(this.CloseSerialPort_Click);
            // 
            // OpenSerialPort
            // 
            this.OpenSerialPort.Location = new System.Drawing.Point(320, 142);
            this.OpenSerialPort.Name = "OpenSerialPort";
            this.OpenSerialPort.Size = new System.Drawing.Size(75, 23);
            this.OpenSerialPort.TabIndex = 1;
            this.OpenSerialPort.Text = "Ouvrir le port";
            this.OpenSerialPort.UseVisualStyleBackColor = true;
            this.OpenSerialPort.Click += new System.EventHandler(this.OpenSerialPort_Click);
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 19200;
            this.serialPort1.PortName = "COM3";
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(0, 27);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(467, 330);
            this.tabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.OpenSerialPort);
            this.tabPage1.Controls.Add(this.CloseSerialPort);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(459, 304);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Général";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.BChauffage);
            this.groupBox2.Controls.Add(this.BVanne);
            this.groupBox2.Controls.Add(this.BVolet);
            this.groupBox2.Controls.Add(this.BLumiere);
            this.groupBox2.Location = new System.Drawing.Point(8, 132);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(159, 153);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Controles";
            // 
            // BChauffage
            // 
            this.BChauffage.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.BChauffage.ImageIndex = 0;
            this.BChauffage.Location = new System.Drawing.Point(9, 121);
            this.BChauffage.Name = "BChauffage";
            this.BChauffage.Size = new System.Drawing.Size(99, 23);
            this.BChauffage.TabIndex = 12;
            this.BChauffage.Text = "  Chauffage";
            this.BChauffage.UseVisualStyleBackColor = true;
            this.BChauffage.Click += new System.EventHandler(this.BChauffage_Click);
            // 
            // BVanne
            // 
            this.BVanne.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BVanne.Location = new System.Drawing.Point(9, 92);
            this.BVanne.Name = "BVanne";
            this.BVanne.Size = new System.Drawing.Size(99, 23);
            this.BVanne.TabIndex = 13;
            this.BVanne.Text = " Vanne";
            this.BVanne.UseVisualStyleBackColor = true;
            this.BVanne.Click += new System.EventHandler(this.BVanne_Click);
            // 
            // BVolet
            // 
            this.BVolet.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BVolet.Location = new System.Drawing.Point(9, 63);
            this.BVolet.Name = "BVolet";
            this.BVolet.Size = new System.Drawing.Size(99, 23);
            this.BVolet.TabIndex = 14;
            this.BVolet.Text = " Volet";
            this.BVolet.UseVisualStyleBackColor = true;
            this.BVolet.Click += new System.EventHandler(this.BVolet_Click);
            // 
            // BLumiere
            // 
            this.BLumiere.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BLumiere.Location = new System.Drawing.Point(9, 34);
            this.BLumiere.Name = "BLumiere";
            this.BLumiere.Size = new System.Drawing.Size(99, 23);
            this.BLumiere.TabIndex = 11;
            this.BLumiere.Text = " Lumière";
            this.BLumiere.UseVisualStyleBackColor = true;
            this.BLumiere.Click += new System.EventHandler(this.BLumiere_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BMaJ);
            this.groupBox1.Controls.Add(this.TBLumiere);
            this.groupBox1.Controls.Add(this.TBHygro);
            this.groupBox1.Controls.Add(this.TBTempExt);
            this.groupBox1.Controls.Add(this.TBTempInt);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Location = new System.Drawing.Point(8, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(397, 120);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dernières mesures";
            // 
            // BMaJ
            // 
            this.BMaJ.Location = new System.Drawing.Point(278, 49);
            this.BMaJ.Name = "BMaJ";
            this.BMaJ.Size = new System.Drawing.Size(96, 23);
            this.BMaJ.TabIndex = 9;
            this.BMaJ.Text = "Mettre à jour";
            this.BMaJ.UseVisualStyleBackColor = true;
            this.BMaJ.Click += new System.EventHandler(this.BMaJ_Click);
            // 
            // TBLumiere
            // 
            this.TBLumiere.Location = new System.Drawing.Point(81, 94);
            this.TBLumiere.Name = "TBLumiere";
            this.TBLumiere.ReadOnly = true;
            this.TBLumiere.Size = new System.Drawing.Size(100, 20);
            this.TBLumiere.TabIndex = 8;
            // 
            // TBHygro
            // 
            this.TBHygro.Location = new System.Drawing.Point(81, 72);
            this.TBHygro.Name = "TBHygro";
            this.TBHygro.ReadOnly = true;
            this.TBHygro.Size = new System.Drawing.Size(100, 20);
            this.TBHygro.TabIndex = 7;
            // 
            // TBTempExt
            // 
            this.TBTempExt.Location = new System.Drawing.Point(131, 46);
            this.TBTempExt.Name = "TBTempExt";
            this.TBTempExt.ReadOnly = true;
            this.TBTempExt.Size = new System.Drawing.Size(100, 20);
            this.TBTempExt.TabIndex = 6;
            // 
            // TBTempInt
            // 
            this.TBTempInt.Location = new System.Drawing.Point(131, 23);
            this.TBTempInt.Name = "TBTempInt";
            this.TBTempInt.ReadOnly = true;
            this.TBTempInt.Size = new System.Drawing.Size(100, 20);
            this.TBTempInt.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 97);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Luminosité :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 75);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Hygrométrie :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(122, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Température extérieure :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Température intérieure :";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.CBStop);
            this.tabPage2.Controls.Add(this.CBParity);
            this.tabPage2.Controls.Add(this.BSaveConfigPort);
            this.tabPage2.Controls.Add(this.TBBit);
            this.tabPage2.Controls.Add(this.TBBaudRate);
            this.tabPage2.Controls.Add(this.TBSerialPort);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(459, 304);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Configuration";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // CBStop
            // 
            this.CBStop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBStop.FormattingEnabled = true;
            this.CBStop.Items.AddRange(new object[] {
            "1",
            "1.5",
            "2"});
            this.CBStop.Location = new System.Drawing.Point(84, 135);
            this.CBStop.Name = "CBStop";
            this.CBStop.Size = new System.Drawing.Size(121, 21);
            this.CBStop.TabIndex = 12;
            // 
            // CBParity
            // 
            this.CBParity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBParity.FormattingEnabled = true;
            this.CBParity.Items.AddRange(new object[] {
            "None",
            "Pair",
            "Impaire"});
            this.CBParity.Location = new System.Drawing.Point(84, 106);
            this.CBParity.Name = "CBParity";
            this.CBParity.Size = new System.Drawing.Size(121, 21);
            this.CBParity.TabIndex = 11;
            // 
            // BSaveConfigPort
            // 
            this.BSaveConfigPort.Location = new System.Drawing.Point(84, 193);
            this.BSaveConfigPort.Name = "BSaveConfigPort";
            this.BSaveConfigPort.Size = new System.Drawing.Size(75, 23);
            this.BSaveConfigPort.TabIndex = 10;
            this.BSaveConfigPort.Text = "Sauvegarder";
            this.BSaveConfigPort.UseVisualStyleBackColor = true;
            this.BSaveConfigPort.Click += new System.EventHandler(this.BSaveConfigPort_Click);
            // 
            // TBBit
            // 
            this.TBBit.Location = new System.Drawing.Point(108, 73);
            this.TBBit.Name = "TBBit";
            this.TBBit.Size = new System.Drawing.Size(100, 20);
            this.TBBit.TabIndex = 8;
            // 
            // TBBaudRate
            // 
            this.TBBaudRate.Location = new System.Drawing.Point(84, 45);
            this.TBBaudRate.Name = "TBBaudRate";
            this.TBBaudRate.Size = new System.Drawing.Size(100, 20);
            this.TBBaudRate.TabIndex = 6;
            // 
            // TBSerialPort
            // 
            this.TBSerialPort.Location = new System.Drawing.Point(84, 19);
            this.TBSerialPort.Name = "TBSerialPort";
            this.TBSerialPort.Size = new System.Drawing.Size(100, 20);
            this.TBSerialPort.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 138);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Sopt Bit :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Nombre de Bits :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Parité :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "BaudRate :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Port N° :";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.BEraseMemory);
            this.tabPage3.Controls.Add(this.LNbreRec);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.BRecupData);
            this.tabPage3.Controls.Add(this.PGBDownload);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(459, 304);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Enregistrements";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // BEraseMemory
            // 
            this.BEraseMemory.Location = new System.Drawing.Point(187, 21);
            this.BEraseMemory.Name = "BEraseMemory";
            this.BEraseMemory.Size = new System.Drawing.Size(117, 23);
            this.BEraseMemory.TabIndex = 10;
            this.BEraseMemory.Text = "Effacer la mémoire";
            this.BEraseMemory.UseVisualStyleBackColor = true;
            this.BEraseMemory.Click += new System.EventHandler(this.BEraseMemory_Click);
            // 
            // LNbreRec
            // 
            this.LNbreRec.AutoSize = true;
            this.LNbreRec.Location = new System.Drawing.Point(142, 64);
            this.LNbreRec.Name = "LNbreRec";
            this.LNbreRec.Size = new System.Drawing.Size(13, 13);
            this.LNbreRec.TabIndex = 9;
            this.LNbreRec.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 64);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(138, 13);
            this.label10.TabIndex = 8;
            this.label10.Text = "Nombre d\'enregistrements : ";
            // 
            // BRecupData
            // 
            this.BRecupData.Location = new System.Drawing.Point(8, 21);
            this.BRecupData.Name = "BRecupData";
            this.BRecupData.Size = new System.Drawing.Size(125, 23);
            this.BRecupData.TabIndex = 7;
            this.BRecupData.Text = "Récupérer les données";
            this.BRecupData.UseVisualStyleBackColor = true;
            this.BRecupData.Click += new System.EventHandler(this.BRecupData_Click);
            // 
            // PGBDownload
            // 
            this.PGBDownload.Location = new System.Drawing.Point(8, 220);
            this.PGBDownload.Name = "PGBDownload";
            this.PGBDownload.Size = new System.Drawing.Size(390, 23);
            this.PGBDownload.TabIndex = 6;
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "GestionSerre (*.gsd)|*.gsd|fichier xml (*.xml)|*.xml";
            // 
            // PBLedConnexion
            // 
            this.PBLedConnexion.Location = new System.Drawing.Point(421, 363);
            this.PBLedConnexion.Name = "PBLedConnexion";
            this.PBLedConnexion.Size = new System.Drawing.Size(34, 34);
            this.PBLedConnexion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.PBLedConnexion.TabIndex = 0;
            this.PBLedConnexion.TabStop = false;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "ledoff.bmp");
            this.imageList1.Images.SetKeyName(1, "ledon.bmp");
            // 
            // timer1
            // 
            this.timer1.Interval = 10000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1, 373);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 13);
            this.label11.TabIndex = 5;
            this.label11.Text = "Version : ";
            // 
            // LVersion
            // 
            this.LVersion.AutoSize = true;
            this.LVersion.Location = new System.Drawing.Point(49, 373);
            this.LVersion.Name = "LVersion";
            this.LVersion.Size = new System.Drawing.Size(13, 13);
            this.LVersion.TabIndex = 6;
            this.LVersion.Text = "0";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aProposToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(467, 24);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // aProposToolStripMenuItem
            // 
            this.aProposToolStripMenuItem.Name = "aProposToolStripMenuItem";
            this.aProposToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.aProposToolStripMenuItem.Text = "A propos";
            this.aProposToolStripMenuItem.Click += new System.EventHandler(this.aProposToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(467, 409);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.LVersion);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.PBLedConnexion);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Gestion Serre";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBLedConnexion)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CloseSerialPort;
        private System.Windows.Forms.Button OpenSerialPort;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox TBBit;
        private System.Windows.Forms.TextBox TBBaudRate;
        private System.Windows.Forms.TextBox TBSerialPort;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BSaveConfigPort;
        private System.Windows.Forms.ComboBox CBParity;
        private System.Windows.Forms.ComboBox CBStop;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BMaJ;
        private System.Windows.Forms.TextBox TBLumiere;
        private System.Windows.Forms.TextBox TBHygro;
        private System.Windows.Forms.TextBox TBTempExt;
        private System.Windows.Forms.TextBox TBTempInt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button BRecupData;
        private System.Windows.Forms.ProgressBar PGBDownload;
        private System.Windows.Forms.PictureBox PBLedConnexion;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button BVolet;
        private System.Windows.Forms.Button BVanne;
        private System.Windows.Forms.Button BChauffage;
        private System.Windows.Forms.Button BLumiere;
        private System.Windows.Forms.Timer timer1;
        public System.Windows.Forms.Label LNbreRec;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label LVersion;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aProposToolStripMenuItem;
        private System.Windows.Forms.Button BEraseMemory;
    }
}

