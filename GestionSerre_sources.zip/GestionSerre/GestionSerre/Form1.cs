﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using System.Media;
using System.Reflection;
namespace GestionSerre
{
    public partial class Form1 : Form
    {
        string NomFichier="";
        bool InProtocol = false, waitAnswer = false, canClose = true;
        int NbreRecord, NumRecord = 0;
        bool NextMesure = false;
        bool EtatVanne, EtatChauffage, EtatVolet, EtatLumiere;
        bool StartLoad = false;
        bool downloadOK = false;
        string LastCommand="";
        string VersionSysteme,DefType;
        //Nécessaire pour éviter un plantage quand on dimensionne le progressBar
        public delegate void SetProgressBarMaxCallBack(int NbreMax);
        public delegate void SetLabelText(string NombreRec);
        public delegate void SetLabelTextV(string TheVersion);
        public delegate void SetImageLedConnexion(Image MonImage);
        public delegate void SetTextTempInt(string LaMesureAffichee);
        public Form1()
        {
            InitializeComponent();
        }

        private void OpenSerialPort_Click(object sender, EventArgs e)
        {
            if (!(serialPort1.IsOpen))
            {
                try
                {
                    InitProtocol();
                }
                catch
                {
                    MessageBox.Show("Erreur ouverture port");
                }
            }
        }

        public void RempliFichierXML(string NomduFichier, string DateM, string HeureM, string TypeM, string ValM, string Version, string Deftype, bool finalisation = true)
        {
            //Header XML
            string[] Header = {
                "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>",
                "<Editiel98>",
                "<Entete>",
                "",
                "",
                "</Entete>",
                "<Mesures>"
            };
            //Structure de la mesure
            string[] Mesure =
            {
                "<NewMesure>",
                "",
                "",
                "",
                "",
                "</NewMesure>"
            };
            Header[3] = "<DefType>" + Deftype + "</DefType>";  //On insère les bonnes valeurs
            Header[4] = "<version>" + Version + "</version>";
            if (!File.Exists(NomduFichier)) //on créer le fichier une seule fois, avec les en tetes XML
            {
                File.WriteAllLines(NomduFichier, Header, Encoding.UTF8);
            }
            //On met en forme la mesure et on l'écrit dans le fichier
            Mesure[1] = "<DateMesure>" + DateM + "</DateMesure>";
            Mesure[2] = "<HeureMesure>" + HeureM + "</HeureMesure>";
            Mesure[3] = "<TypeMesure>" + TypeM + "</TypeMesure>";
            Mesure[4] = "<ValeurMesure>" + ValM + "</ValeurMesure>";
            File.AppendAllLines(NomduFichier, Mesure, Encoding.UTF8);
            if (finalisation)  //On finalise le xml
            {
                string[] footer =
                {
                    "</Mesures>",
                    "</Editiel98>"
                };
                File.AppendAllLines(NomduFichier, footer, Encoding.UTF8);
            }
        }

        public void InitProtocol()
        {
            int i = 100000;  //Pour la boucle d'attente
            if (!serialPort1.IsOpen)
            {
                serialPort1.Open();
                while (serialPort1.BytesToRead > 0)
                {
                    serialPort1.DiscardInBuffer();  //On vide le plausible buffer sériel
                }
            }
            while(i>0)   //boucle d'attente si on dépasse 9600 bds
            {
                Application.DoEvents();
                i--;
            }
            serialPort1.WriteLine("?");
            LastCommand = "?";
        }

        private void CloseSerialPort_Click(object sender, EventArgs e)
        {
            ExitProtocol(0);
        }
 
        //Réception sur le port série
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            string RecuFrom = "";
            char FirstChar;
            RecuFrom = serialPort1.ReadLine();
            RecuFrom = RecuFrom.TrimEnd('\r');
            FirstChar = RecuFrom[0];
            if (RecuFrom == "PNOK")
            {
                ExitProtocol(1);
            }
            //traitement du scan 
            switch (LastCommand)
            {
                case "?":
                    if (RecuFrom != DefType)
                    {
                        //On est pas dans le protocole et on a pas affaire au bon coffret
                        ExitProtocol(2);

                    }
                    else
                    {
                        serialPort1.WriteLine("V");
                        LastCommand = "V";
                    }
                    break;
                case "V":  //On attend la version du coffret
                    if (RecuFrom != VersionSysteme)
                    {
                        ExitProtocol(3);
                    }
                    else
                    {
                        InProtocol = true;
                        SetImageLed(imageList1.Images[1]);
                        //Envoie au coffret le fait que le protocole est accepté
                        serialPort1.WriteLine("POK");
                        LastCommand = "";
                    }
                    break;
                case "G1": //température intérieure
                    if (InProtocol)
                    {

                        LastCommand = "";
                        TraiteMesure(1, RecuFrom);
                        
                    }
                    else
                    {
                        ExitProtocol(4);
                    }

                    break;
                case "G2":  //température extérieure
                    if (InProtocol)
                    {
                        LastCommand = "";
                        TraiteMesure(2, RecuFrom);
                        
                    }
                    else
                    {
                        ExitProtocol(4);
                    }

                    break;
                case "G3":  //Hygrométrie
                    if (InProtocol)
                    {
                        LastCommand = "";
                        TraiteMesure(3, RecuFrom);
                        
                    }
                    else
                    {
                        ExitProtocol(4);
                    }

                    break;
                case "G4":  //Luminosité
                    if (InProtocol)
                    {
                        LastCommand = "";
                        TraiteMesure(4, RecuFrom);
                    }
                    else
                    {
                        ExitProtocol(4);
                    }

                    break;
                case "M":
                    if (InProtocol)
                    {
                        //MessageBox.Show("Il y a " + RecuFrom + " enregistrements en mémoire");
                        NbreRecord = Int32.Parse(RecuFrom);
                        SetTextLabelRecord(NbreRecord.ToString());
                        LastCommand = "";
                        SetProgressBarMax(NbreRecord);
                        PGBDownload.Value = 0;
                        StartLoad = true;
                    }
                    else
                    {
                        ExitProtocol(4);
                    }
                    break;
                case "GR":  /////////////////////////////get record
                    if (InProtocol)
                    {
                        TraiteRecord(RecuFrom, NumRecord);
                        LastCommand = "";
                    }
                    else
                    {
                        ExitProtocol(4);
                    }
                    break;
                case "ER":
                    if (InProtocol)
                    {
                        if (RecuFrom=="OK")
                        {
                            MessageBox.Show("Effacement de la mémoire effectué !");
                        }
                        else
                        {
                            MessageBox.Show("Erreur de suppréssion de la mémoire !");
                        }
                        LastCommand = "";
                    }
                    else
                    {
                        ExitProtocol(4);
                    }
                    break;
                case "SC":                 //Set Chauffage 
                    if (InProtocol)
                    {
                        if(RecuFrom=="0")
                        {
                            TraiteMesure(5, RecuFrom);
                            LastCommand = "";
                        }
                        else if (RecuFrom == "1")
                        {
                            TraiteMesure(5, RecuFrom);
                            LastCommand = "";
                        }
                        else if(RecuFrom=="PNOK")
                        {
                            ExitProtocol(7); 
                        }
                        
                    }
                    else
                    {
                        ExitProtocol(4);
                    }
                    break;
                case "SV":                 //Set Vanne 
                    if (InProtocol)
                    {
                        if (RecuFrom == "0")
                        {
                            TraiteMesure(6, RecuFrom);
                            LastCommand = "";
                        }
                        else if (RecuFrom == "1")
                        {
                            TraiteMesure(6, RecuFrom);
                            LastCommand = "";
                        }
                        else if (RecuFrom == "PNOK")
                        {
                            ExitProtocol(7);
                        }
                    }
                    else
                    {
                        ExitProtocol(4);
                    }
                    break;
                case "ST":                 //Set Volet 
                    if (InProtocol)
                    {
                        if (RecuFrom == "0")
                        {
                            TraiteMesure(7, RecuFrom);
                            LastCommand = "";
                        }
                        else if (RecuFrom == "1")
                        {
                            TraiteMesure(7, RecuFrom);
                            LastCommand = "";
                        }
                        else if (RecuFrom == "PNOK")
                        {
                            ExitProtocol(7);
                        }
                    }
                    else
                    {
                        ExitProtocol(4);
                    }
                    break;
                case "SL":                 //Set Lumière 
                    if (InProtocol)
                    {
                        if (RecuFrom == "0")
                        {
                            TraiteMesure(8, RecuFrom);
                            LastCommand = "";
                        }
                        else if (RecuFrom == "1")
                        {
                            TraiteMesure(8, RecuFrom);
                            LastCommand = "";
                        }
                        else if (RecuFrom == "PNOK")
                        {
                            ExitProtocol(7);
                        }
                    }
                    else
                    {
                        ExitProtocol(4);
                    }
                    break;
                default:
                    InProtocol = false;
                    ExitProtocol(5);
                    break;
            }
        }

        public void TraiteMesure(int NumMesure, string Mesure)
        {
            string Resultat;
            int MesureConvertie,temp1,temp2;
            Image AfficheLedSortie;
            //On traite la mesure
            switch(NumMesure)
            {
                case 1:  //Temp. Intérieure
                    try
                    {
                        
                        MesureConvertie = Int32.Parse(Mesure);
                        temp1 = MesureConvertie / 2;
                        temp2 = MesureConvertie % 2;
                        if (temp2==1)
                        {
                            temp2=5;
                        }
                        else
                        {
                            temp2 = 0;
                        }
                        Resultat =temp1.ToString()+"."+temp2.ToString()+"°C";
                        SetTextEditTempInt(Resultat);
                    }
                    catch
                    {
                        MessageBox.Show("Impossible a faire !");
                    }
                    break;
                case 2:  //Temp Ext
                    try
                    {
                        MesureConvertie = Int32.Parse(Mesure);
                        temp1 = MesureConvertie / 2;
                        temp2 = MesureConvertie % 2;
                        if (temp2 == 1)
                        {
                            temp2 = 5;
                        }
                        else
                        {
                            temp2 = 0;
                        }
                        Resultat = temp1.ToString() + "." + temp2.ToString() + "°C";
                        SetTextEditTempExt(Resultat);
                    }
                    catch
                    {
                        MessageBox.Show("Exterieur !");
                    }
                    break;
                case 3:  //Hygro
                    SetTextEditHygro(Mesure);
                    break;
                case 4:  //Lumière
                    SetTextEditLumiere(Mesure);
                    break;
                case 5:  //Met en Etat l'info sortie Chauffage
                    //MessageBox.Show("Chauffage ="+Mesure);
                    AfficheLedSortie = imageList1.Images[0];
                    if (Mesure=="0")
                    {
                        AfficheLedSortie =imageList1.Images[0];
                        EtatChauffage = false;
                    }
                    else if (Mesure=="1")
                    {
                        AfficheLedSortie = imageList1.Images[1];
                        EtatChauffage = true;
                    }
                    //SetImageChauffage(AfficheLedSortie);
                   
                    BChauffage.Image = AfficheLedSortie;
                    break;
                case 6:  //Met en Etat l'info sortie Vanne
                    //MessageBox.Show("Vanne =" + Mesure);
                    AfficheLedSortie = imageList1.Images[0];
                    if (Mesure == "0")
                    {
                        AfficheLedSortie = imageList1.Images[0];
                        EtatVanne = false;
                    }
                    else if (Mesure == "1")
                    {
                        AfficheLedSortie = imageList1.Images[1];
                        EtatVanne = true;
                    }
                    //SetImageVanne(AfficheLedSortie);
                   
                    BVanne.Image= AfficheLedSortie;
                    break;
                case 7:  //Met en Etat l'info sortie Volet
                    //MessageBox.Show("Volet =" + Mesure);
                    AfficheLedSortie = imageList1.Images[0];
                    if (Mesure == "0")
                    {
                        AfficheLedSortie = imageList1.Images[0];
                        EtatVolet = false;
                    }
                    else if (Mesure == "1")
                    {
                        AfficheLedSortie = imageList1.Images[1];
                        EtatVolet = true;
                    }
                    //SetImageVolet(AfficheLedSortie);
                    
                    BVolet.Image = AfficheLedSortie;
                    break;
                case 8:  //Met en Etat l'info sortie Lumière
                    //MessageBox.Show("Lumière =" + Mesure);
                    AfficheLedSortie = imageList1.Images[0];
                    if (Mesure == "0")
                    {
                        AfficheLedSortie = imageList1.Images[0];
                        EtatLumiere = false;
                    }
                    else if (Mesure == "1")
                    {
                        AfficheLedSortie = imageList1.Images[1];
                        EtatLumiere = true;
                    }
                    //SetImageLumiere(AfficheLedSortie);
                   
                    BLumiere.Image = AfficheLedSortie;
                    break;
                default:
                    break;
            }
            NextMesure = false;
        }

        public void ExitProtocol(int NumErreur)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.WriteLine("PNOK");
                while (serialPort1.BytesToRead > 0)
                {
                    serialPort1.DiscardInBuffer();  //On vide le plausible buffer sériel
                }
                serialPort1.Close();
                SetImageLed(imageList1.Images[0]);
                InProtocol = false;
                waitAnswer = false;
                NbreRecord = 0;
                canClose = true;
                LastCommand = "";
                if (NumErreur != 0)
                {
                    MessageBox.Show("Erreur de communication : " + NumErreur.ToString());
                }
            }
            timer1.Stop();
            timer1.Enabled = false;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = !canClose;
            ExitProtocol(0);
            
            serialPort1.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Pré initialisation des variables
            EtatLumiere = false;
            EtatChauffage = false;
            EtatVanne = false;
            EtatVolet = false;
            //Ici, on met l'initialisation
            Microsoft.Win32.RegistryKey key;
            int ParitySel, StopBitSel;
            VersionSysteme = "1.0";
            SetTextLabelVersion(VersionSysteme);
            DefType = "GestionSerre";
            //On affiche l'image hors ligne
            PBLedConnexion.Image = imageList1.Images[0];
            try
            {
                //Ouvre la clé et récupère les valeurs
                key = Microsoft.Win32.Registry.CurrentUser.CreateSubKey("Editiel98\\GestionSerre");
                TBBaudRate.Text = key.GetValue("BaudRate").ToString();
                serialPort1.BaudRate = (int)key.GetValue("BaudRate",9600);
                TBSerialPort.Text = key.GetValue("COMPORT").ToString();
                serialPort1.PortName= key.GetValue("COMPORT").ToString();
                serialPort1.DataBits = (int)key.GetValue("DataBit");
                TBBit.Text= key.GetValue("DataBit").ToString();
                //tempo
                ParitySel = (int)key.GetValue("Parite");
                CBParity.SelectedIndex = ParitySel;
                switch (ParitySel)
                {
                    case 0:   //None
                        serialPort1.Parity = System.IO.Ports.Parity.None;
                        break;
                    case 1:  //Paire
                        serialPort1.Parity = System.IO.Ports.Parity.Even;
                        break;
                    case 2:  //Impaire
                        serialPort1.Parity = System.IO.Ports.Parity.Odd;
                        break;
                    default:  // Si autre, on repasse à pair et on remet l'index à 0
                        serialPort1.Parity = System.IO.Ports.Parity.None;
                        CBParity.SelectedIndex = 0;
                        break;
                }
                StopBitSel= (int)key.GetValue("Stop");
                CBStop.SelectedIndex = StopBitSel;
                switch (StopBitSel)
                {
                    case 0:  //1
                        serialPort1.StopBits = System.IO.Ports.StopBits.One;
                        break;
                    case 1:  //1.5
                        serialPort1.StopBits = System.IO.Ports.StopBits.OnePointFive;
                        break;
                    case 2:  //2
                        serialPort1.StopBits = System.IO.Ports.StopBits.Two;
                        break;
                    default:  // Si autre, on repasse à 1 et on remet l'index à 0
                        serialPort1.StopBits = System.IO.Ports.StopBits.One;
                        CBStop.SelectedIndex = 1;
                        break;
                }
            }
            catch
            {
                //Si erreur
                serialPort1.BaudRate = 9600;
                serialPort1.PortName = "COM3";
                serialPort1.Parity = System.IO.Ports.Parity.None;
                serialPort1.DataBits = 8;
                serialPort1.StopBits = System.IO.Ports.StopBits.One;
                MessageBox.Show("Erreur de lecture de la configuration. Mode par défaut !");
                TBBaudRate.Text = "9600";
                TBSerialPort.Text = "COM3";
                TBBit.Text = "8";
                CBParity.SelectedIndex = 0;
                CBStop.SelectedIndex = 1;
            }
        }

        private void SetImageLed(Image LedAAfficher)
        {
            if (PBLedConnexion.InvokeRequired)
            {
                SetImageLedConnexion d = new SetImageLedConnexion(SetImageLed);
                PBLedConnexion.Invoke(d, new object[] { LedAAfficher });
            }
            else
            {
                PBLedConnexion.Image = LedAAfficher;
            }
        }

      /*  private void SetImageChauffage(Image LedAAfficher)
        {
            if (pbChauffage.InvokeRequired)
            {
                SetImageLedConnexion d = new SetImageLedConnexion(SetImageLed);
                pbChauffage.Invoke(d, new object[] { LedAAfficher });
            }
            else
            {
                pbChauffage.Image = LedAAfficher;
            }
        }

        private void SetImageVanne(Image LedAAfficher)
        {
            if (PBVanne.InvokeRequired)
            {
                SetImageLedConnexion d = new SetImageLedConnexion(SetImageLed);
                PBVanne.Invoke(d, new object[] { LedAAfficher });
            }
            else
            {
                PBVanne.Image = LedAAfficher;
            }
        }

        private void SetImageVolet(Image LedAAfficher)
        {
            if (PBVolet.InvokeRequired)
            {
                SetImageLedConnexion d = new SetImageLedConnexion(SetImageLed);
                PBVolet.Invoke(d, new object[] { LedAAfficher });
            }
            else
            {
                PBVolet.Image = LedAAfficher;
            }
        }

        private void SetImageLumiere(Image LedAAfficher)
        {
            if (PBLumiere.InvokeRequired)
            {
                SetImageLedConnexion d = new SetImageLedConnexion(SetImageLed);
                PBLumiere.Invoke(d, new object[] { LedAAfficher });
            }
            else
            {
                PBLumiere.Image = LedAAfficher;
            }
        }*/

        private void SetProgressBarMax(int NbreMax)
        {
            if (PGBDownload.InvokeRequired)
            {
                SetProgressBarMaxCallBack d = new SetProgressBarMaxCallBack(SetProgressBarMax);
                PGBDownload.Invoke(d, new object[] { NbreMax });
            }
            else
            {
                PGBDownload.Maximum = NbreMax;
            }
        }

        private void SetTextLabelRecord(string LeNombre)
        {
            if (LNbreRec.InvokeRequired)
            {
                SetLabelText d = new SetLabelText(SetTextLabelRecord);
                LNbreRec.Invoke(d, new object[] { LeNombre });
            }
            else
            {
                LNbreRec.Text = LeNombre;
            }
        }
        private void SetTextLabelVersion(string LaVersion)
        {
            if (LVersion.InvokeRequired)
            {
                SetLabelTextV d = new SetLabelTextV(SetTextLabelVersion);
                LVersion.Invoke(d, new object[] { LaVersion });
            }
            else
            {
                LVersion.Text = LaVersion;
            }
        }
        private void SetTextEditTempInt(string LaMesureAff)
        {
            if (TBTempInt.InvokeRequired)
            {
                SetTextTempInt d = new SetTextTempInt(SetTextEditTempInt);
                TBTempInt.Invoke(d, new object[] { LaMesureAff });
            }
            else
            {
                TBTempInt.Text = LaMesureAff;
            }   

        }
        private void SetTextEditTempExt(string LaMesureAff)
        {
            if (TBTempExt.InvokeRequired)
            {
                SetTextTempInt d = new SetTextTempInt(SetTextEditTempExt);
                TBTempExt.Invoke(d, new object[] { LaMesureAff });
            }
            else
            {
                TBTempExt.Text = LaMesureAff;
            }

        }
        private void SetTextEditHygro(string LaMesureAff)
        {
            if (TBHygro.InvokeRequired)
            {
                SetTextTempInt d = new SetTextTempInt(SetTextEditHygro);
                TBHygro.Invoke(d, new object[] { LaMesureAff });
            }
            else
            {
                TBHygro.Text = LaMesureAff;
            }

        }
        private void SetTextEditLumiere(string LaMesureAff)
        {
            if (TBTempExt.InvokeRequired)
            {
                SetTextTempInt d = new SetTextTempInt(SetTextEditLumiere);
                TBLumiere.Invoke(d, new object[] { LaMesureAff });
            }
            else
            {
                TBLumiere.Text = LaMesureAff;
            }

        }

        private void BSaveConfigPort_Click(object sender, EventArgs e)
        {
            Microsoft.Win32.RegistryKey key;
            int SetBaudRate,SetBit,ParitySel,StopSel;
            string NomPort;
            try
            {

                key = Microsoft.Win32.Registry.CurrentUser.CreateSubKey("Editiel98\\GestionSerre");
                //Conversion des valeurs pour le stockage en BDR du baudRate
                if (!(int.TryParse(TBBaudRate.Text,out SetBaudRate)))  //Si la conversion echoue, on passe à 9600
                {
                    SetBaudRate = 9600;
                   // MessageBox.Show("Erreur conversion !");
                }
                //Stockage en BDR
                key.SetValue("Baudrate", SetBaudRate);
                serialPort1.BaudRate = SetBaudRate;
                NomPort = TBSerialPort.Text;
                serialPort1.PortName = NomPort;
                key.SetValue("COMPORT", NomPort);
                //Conversion des valeurs pour le stockage en BDR du nombre de bits
                if (!(int.TryParse(TBBit.Text, out SetBit)))  //Si la conversion echoue, on passe à 9600
                {
                    SetBit = 9600;
                   // MessageBox.Show("Erreur conversion !");
                }
                serialPort1.DataBits = SetBit;
                key.SetValue("DataBit", SetBit);
                //Parité
                ParitySel = CBParity.SelectedIndex;
                key.SetValue("Parite", ParitySel);
                switch (ParitySel)
                {
                    case 0:   //None
                        serialPort1.Parity = System.IO.Ports.Parity.None;
                        break;
                    case 1:  //Paire
                        serialPort1.Parity = System.IO.Ports.Parity.Even;
                        break;
                    case 2:  //Impaire
                        serialPort1.Parity = System.IO.Ports.Parity.Odd;
                        break;
                    default:  // Si autre, on repasse à pair et on remet l'index à 0
                        serialPort1.Parity = System.IO.Ports.Parity.None;
                        CBParity.SelectedIndex = 0;
                        break;
                }
                StopSel = CBStop.SelectedIndex;
                key.SetValue("Stop", StopSel);
                switch (StopSel)
                {
                    case 0:  //1
                        serialPort1.StopBits = System.IO.Ports.StopBits.One; ;
                        break;
                    case 1:  //1.5
                        serialPort1.StopBits = System.IO.Ports.StopBits.OnePointFive; ;
                        break;
                    case 2:  //2
                        serialPort1.StopBits = System.IO.Ports.StopBits.Two; ;
                        break;
                    default:  // Si autre, on repasse à 1 et on remet l'index à 0
                        serialPort1.StopBits = System.IO.Ports.StopBits.None;
                        CBStop.SelectedIndex = 0;
                        break;
                }
            }
            catch
            {
                MessageBox.Show("Erreur lors de la sauvegarde !");
            }
            finally
            {

            }
        }

        private void BMaJ_Click(object sender, EventArgs e)
        {
            ///////////////////////////////////////////////////////////////////
            downloadOK = false;
            string CommandeEnvoyee;
            string[] Cde =
            {
                "G1",
                "G2",
                "G3",
                "G4",
                "SC",
                "SV",
                "ST",
                "SL"
            };      
            if (InProtocol)
            {
                timer1.Enabled = false;  //On bloque le timer le temps des mises à jour
                for (int i = 0; i < 8; i++)
                {
                    NextMesure = true;
                    if (i > 3)
                    {
                        CommandeEnvoyee = Cde[i] + "-?";
                    }
                    else
                    {
                        CommandeEnvoyee = Cde[i];
                    } 
                    serialPort1.WriteLine(CommandeEnvoyee);
                    LastCommand = Cde[i];
                    while(NextMesure)
                    {
                        Application.DoEvents();
                    }
                }
                timer1.Enabled = true;  //On relance le timer
            }
        }

   
        private void BLumiere_Click(object sender, EventArgs e)
        {
            string EnvoiCommande;
            if (InProtocol)
            {
                if (EtatLumiere)    //Si on est allumé alors on éteint
                {
                    EnvoiCommande = "SL-0";
                }   
                else
                {
                    EnvoiCommande = "SL-1";
                }
                serialPort1.WriteLine(EnvoiCommande);
                LastCommand = "SL";
            }

        }

        

        private void aProposToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Version ver;
            Assembly assem = typeof(Form1).Assembly;
            AssemblyName assemName = assem.GetName();
            ver = assemName.Version;
            MessageBox.Show(assemName.Name+"\r"+ver.ToString()+"\r"+"(c) 2016 Editiel98");
        }

        private void BEraseMemory_Click(object sender, EventArgs e)
        {
            if (InProtocol)
            {
                var result=MessageBox.Show("Voulez-vous supprimer la mémoire ?", "Supprimer la mémoire", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    LastCommand = "ER";
                    serialPort1.WriteLine(LastCommand);
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            string CommandeEnvoyee;
            string[] Cde =
            {
                "G1",
                "G2",
                "G3",
                "G4"
            };
            if (InProtocol)
            {
               
                for (int i = 0; i < 4; i++)
                {
                    NextMesure = true;
                    if (i > 3)
                    {
                        CommandeEnvoyee = Cde[i] + "-?";
                    }
                    else
                    {
                        CommandeEnvoyee = Cde[i];
                    }
                    serialPort1.WriteLine(CommandeEnvoyee);
                    LastCommand = Cde[i];
                    while (NextMesure)
                    {
                        Application.DoEvents();
                    }
                }
            }
        }

        private void BVolet_Click(object sender, EventArgs e)
        {
            string EnvoiCommande;
            if (InProtocol)
            {
                if (EtatVolet)    //Si on est allumé alors on éteint
                {
                    EnvoiCommande = "ST-0";
                }
                else
                {
                    EnvoiCommande = "ST-1";
                }
                serialPort1.WriteLine(EnvoiCommande);
                LastCommand = "ST";
            }
        }

        private void BVanne_Click(object sender, EventArgs e)
        {
            string EnvoiCommande;
            if (InProtocol)
            {
                if (EtatVanne)    //Si on est allumé alors on éteint
                {
                    EnvoiCommande = "SV-0";
                }
                else
                {
                    EnvoiCommande = "SV-1";
                }
                serialPort1.WriteLine(EnvoiCommande);
                LastCommand = "SV";
            }
        }

        private void BChauffage_Click(object sender, EventArgs e)
        {
            string EnvoiCommande;
            if (InProtocol)
            {
                if (EtatChauffage)    //Si on est allumé alors on éteint
                {
                    EnvoiCommande = "SC-0";
                }
                else
                {
                    EnvoiCommande = "SC-1";
                }
                serialPort1.WriteLine(EnvoiCommande);
                LastCommand = "SC";
            }
        }

        private void BRecupData_Click(object sender, EventArgs e)
        {
            //On envoi la demande de nombre d'enregistrement.
            NbreRecord = 0;
            StartLoad = false;
            PGBDownload.Value = 0;
            SetTextLabelRecord("0");
            string[] Header = {
                "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>",
                "<Editiel98>",
                "<Entete>",
                "",
                "",
                "</Entete>",
                "<Mesures>"
            };
            if (InProtocol & serialPort1.IsOpen)
            {
                serialPort1.WriteLine("M");
                LastCommand = "M";
                //On attend la réponse de la carte.
                while (!StartLoad)
                {
                    Application.DoEvents();
                }
                //On ouvre la boite de dialogue pour la sauvegarde
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    NomFichier = saveFileDialog1.FileName;

                    //Si le fichier n'existe pas, il est créé et on insère le header
                    if (!File.Exists(NomFichier))
                    {
                        Header[3] = "<DefType>" + DefType + "</DefType>";  //On insère les bonnes valeurs
                        Header[4] = "<version>" + VersionSysteme + "</version>";
                        File.WriteAllLines(NomFichier, Header, Encoding.UTF8);
                    }
                    GetAllMemory();
                }
                //en fin de traitement on bloque de nouveau le traitement
                StartLoad = false;
            }            
        }

        public void TraiteRecord(string MessageRecu, int NumEnregistrement)
        {
            string[] RecordSplit = { };
            int Numrecu;
            string FormatDate, FormatHeure;
            bool FinalisationFichier;
            //On split la chaine
            try
            {
                RecordSplit = MessageRecu.Split('-');
            }
            catch
            {
                ExitProtocol(6);
            }
            //On compare le numéro demandé, NumRenregistrement avec le numéro retourné par le coffret
            if (RecordSplit.Length == 8)
            {
                try
                {
                    Numrecu = Int32.Parse(RecordSplit[0]);
                    if (Numrecu == NumEnregistrement)
                    {
                        //Alors on enregistre les données
                        FormatDate= RecordSplit[1]+"/"+RecordSplit[2]+"/"+RecordSplit[3];
                        FormatHeure = RecordSplit[4] + "h" + RecordSplit[5];
                        if (Numrecu < NbreRecord)
                            FinalisationFichier = false;
                        else
                            FinalisationFichier = true;
                        RempliFichierXML(NomFichier, FormatDate, FormatHeure, RecordSplit[6], RecordSplit[7], VersionSysteme, "GestionSerre", FinalisationFichier);
                        if(FinalisationFichier)
                        {
                            SystemSounds.Exclamation.Play();
                            MessageBox.Show("Récupération terminée avec succès !\rPensez à vider la mémoire.");
                            downloadOK = true;
                        }
                    }
                    else
                    {
                        ExitProtocol(6);
                        SystemSounds.Asterisk.Play();
                        MessageBox.Show("Erreur de récupération");
                        downloadOK = false;
                    }
                }
                catch
                {
                    ExitProtocol(6);
                    SystemSounds.Asterisk.Play();
                    MessageBox.Show("Erreur de récupération");
                    downloadOK = false;
                }
            }
            else
            {
                //On est clairement pas dans le protocole, car la taille est de 8 valeurs
                ExitProtocol(6);
            }
            
            //recu sous la forme 12-21-12-2016-18-47-1-1024
            waitAnswer = false;
        }

        public void GetAllMemory()
        {
            //On va aller chercher les infos dans la mémoire 
            int i;
            string Cde = "";

            //On vérifie si on est dans le protocole et si on a bien recu un nombre de données
            if ((NbreRecord > 0) && InProtocol && serialPort1.IsOpen)
            {
                canClose = false;  //On empeche la fermeture de l'application tant qu'on récupère 
                for (i = 1; i < NbreRecord + 1; i++)
                {
                    waitAnswer = true;  //On attends dans dans la boucle que le traitement de l'enregistrement soit réalisé
                                        //On envoie la requete d'un enregistrement
                    {
                        Cde = "GR_" + i.ToString();
                        serialPort1.WriteLine(Cde);
                        NumRecord = i;
                        LastCommand = "GR";
                        PGBDownload.Value = NumRecord;
                    }
                    //ensuite on attend
                    while (waitAnswer)
                    {
                        Application.DoEvents();
                    }
                    if (!InProtocol)
                    {
                        waitAnswer = false;
                        break;  //on est plus dans le protocole, cela sert à rien de continuer
                    }
                }
                canClose = true;
            }  //Fin si on peut traiter
            else
            {
                MessageBox.Show("Il n'y a pas d'enregistrement ou le port est fermé !");
            }

        }
    }
}
